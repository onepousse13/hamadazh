import { useState } from 'react'
import { useI18n } from './i18n'
import Header from './components/Header'
import Hero from './components/Hero'
import About from './components/About'
import Rooms from './components/Rooms'
import Experiences from './components/Experiences'
import Gallery from './components/Gallery'
import Booking from './components/Booking'
import Contact from './components/Contact'
export default function App() {
  const { t } = useI18n()
  const [room, setRoom] = useState('')
  const book = (id: string) => { setRoom(id); document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' }) }
  return (<>
    <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:bg-ivory focus:p-3">Skip to content</a>
    <Header />
    <main id="main"><Hero /><About /><Rooms onBook={book} /><Experiences /><Gallery /><Booking room={room} setRoom={setRoom} /><Contact /></main>
    <footer className="bg-olive px-6 py-12 text-center text-ivory"><p className="font-serif text-3xl tracking-[.3em]">HAMADA ZH</p><p className="mt-2 text-sm">{t('f_tag')}</p></footer>
  </>)
}
