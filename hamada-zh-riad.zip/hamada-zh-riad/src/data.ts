import type { Pair } from './i18n'
// Royalty-free placeholder photos (Unsplash). Replace with the riad's own photography.
export const u = (id: string, w = 900) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=70`
export const I = { hero: '1539020140153-e479b8c22e70', a: '1597212618440-806262de4f6b', b: '1489749798305-4fea3ae63d43', c: '1548018560-c7196548e84d', d: '1517821099606-cef63a9bcda6', e: '1566073771259-6a8506099945', f: '1582719478250-c89cae4dc85b', g: '1571896349842-33c89424de2d', h: '1544161515-4ab6ce6db874', i: '1414235077428-338989a2e8c0' }
export const pillars: [Pair, Pair][] = [
  [['Moroccan craftsmanship', 'Artisanat marocain'], ['Zellige, tadelakt and carved cedar.', 'Zellige, tadelakt et cèdre sculpté.']],
  [['Traditional architecture', 'Architecture traditionnelle'], ['Courtyard, arches and a rooftop terrace.', 'Patio, arcs et terrasse sur le toit.']],
  [['Authentic hospitality', 'Hospitalité authentique'], ['Mint tea and a warm welcome.', 'Thé à la menthe et accueil chaleureux.']],
  [['Contemporary comfort', 'Confort contemporain'], ['Calm, considered interiors.', 'Intérieurs calmes et soignés.']],
]
// Amenities are sample content joined with "|". Confirm before launch.
export const rooms = [
  { id: 'deluxe', img: I.f, name: ['Deluxe Room', 'Chambre Deluxe'] as Pair, desc: ['A calm room in warm earth tones, opening onto the courtyard.', 'Une chambre paisible aux tons de terre, ouverte sur le patio.'] as Pair, am: ['Courtyard view|Tadelakt bathroom|Air conditioning', 'Vue sur le patio|Salle de bain en tadelakt|Climatisation'] as Pair },
  { id: 'superior', img: I.b, name: ['Superior Suite', 'Suite Supérieure'] as Pair, desc: ['A generous suite with a sitting area and hand-finished details.', 'Une suite généreuse avec salon et détails finis à la main.'] as Pair, am: ['Separate sitting area|Carved cedar ceiling|Air conditioning', 'Salon séparé|Plafond en cèdre sculpté|Climatisation'] as Pair },
  { id: 'royal', img: I.a, name: ['Royal Suite', 'Suite Royale'] as Pair, desc: ['The riad’s finest suite, with room to linger and private terrace access.', 'La plus belle suite du riad, avec accès à une terrasse privée.'] as Pair, am: ['Private terrace|Marble bathroom|Air conditioning', 'Terrasse privée|Salle de bain en marbre|Climatisation'] as Pair },
]
export const experiences: [Pair, Pair][] = [
  [['Traditional Moroccan breakfast', 'Petit-déjeuner marocain traditionnel'], ['Breads, preserves and mint tea served in the courtyard.', 'Pains, confitures et thé à la menthe servis dans le patio.']],
  [['Rooftop sunset', 'Coucher de soleil sur le toit'], ['An evening above the Medina as the call to prayer drifts across.', 'Une soirée au-dessus de la Médina, au rythme de l’appel à la prière.']],
  [['Hammam and wellness', 'Hammam et bien-être'], ['A traditional steam bath and restorative treatments.', 'Un bain de vapeur traditionnel et des soins réparateurs.']],
  [['Medina discovery', 'Découverte de la Médina'], ['A guided walk through souks, workshops and hidden lanes.', 'Une promenade guidée à travers souks, ateliers et ruelles cachées.']],
  [['Moroccan dining', 'Dîner marocain'], ['A table of slow-cooked tagines and seasonal salads.', 'Une table de tajines mijotés et de salades de saison.']],
]
export const cats: [string, Pair][] = [['architecture', ['Architecture', 'Architecture']], ['rooms', ['Rooms', 'Chambres']], ['courtyard', ['Courtyard', 'Patio']], ['rooftop', ['Rooftop', 'Toit-terrasse']], ['lifestyle', ['Lifestyle', 'Art de vivre']]]
export const gallery = ([['architecture', 'a'], ['architecture', 'c'], ['rooms', 'f'], ['rooms', 'b'], ['courtyard', 'hero'], ['courtyard', 'e'], ['rooftop', 'd'], ['rooftop', 'g'], ['lifestyle', 'h'], ['lifestyle', 'i']] as const).map(([cat, k]) => ({ cat: cat as string, id: I[k] }))
