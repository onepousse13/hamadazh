export interface BookingQuery { checkIn: string; checkOut: string; guests: number; roomId: string }
export interface BookingProvider { submit(q: BookingQuery): Promise<{ ok: boolean; ref?: string }> }
// DEMO provider. To go live, implement BookingProvider against your booking engine's API
// (or redirect to its hosted widget) and swap it in Booking.tsx. No request is made here.
export const demoProvider: BookingProvider = { submit: () => new Promise(r => setTimeout(() => r({ ok: true }), 500)) }
