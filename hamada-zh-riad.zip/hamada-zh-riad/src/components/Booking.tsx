import { useState, type FormEvent } from 'react'
import { useI18n } from '../i18n'
import { rooms } from '../data'
import { demoProvider } from '../lib/booking'
import { Title } from './ui'
export default function Booking({ room, setRoom }: { room: string; setRoom: (r: string) => void }) {
  const { t, p } = useI18n()
  const today = new Date().toISOString().slice(0, 10)
  const [f, setF] = useState({ checkIn: '', checkOut: '', guests: 2 })
  const [state, setState] = useState<'idle' | 'err' | 'ok'>('idle')
  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (!f.checkIn || !f.checkOut || f.checkOut <= f.checkIn || !room) return setState('err')
    await demoProvider.submit({ ...f, roomId: room }); setState('ok')
  }
  const lab = 'block text-sm'
  return (
    <section id="booking" className="bg-sand px-6 py-24 md:py-36"><div className="mx-auto max-w-4xl">
      <Title note={t('b_demo')}>{t('b_title')}</Title>
      <form onSubmit={submit} noValidate className="grid gap-x-8 gap-y-7 sm:grid-cols-2">
        <label className={lab}>{t('b_in')}<input type="date" min={today} value={f.checkIn} onChange={e => setF({ ...f, checkIn: e.target.value })} className="field" /></label>
        <label className={lab}>{t('b_out')}<input type="date" min={f.checkIn || today} value={f.checkOut} onChange={e => setF({ ...f, checkOut: e.target.value })} className="field" /></label>
        <label className={lab}>{t('b_guests')}<select value={f.guests} onChange={e => setF({ ...f, guests: +e.target.value })} className="field">{[1, 2, 3, 4, 5, 6].map(n => <option key={n}>{n}</option>)}</select></label>
        <label className={lab}>{t('b_room')}<select value={room} onChange={e => setRoom(e.target.value)} className="field"><option value="">{t('b_pick')}</option>{rooms.map(r => <option key={r.id} value={r.id}>{p(r.name)}</option>)}</select></label>
        <div className="sm:col-span-2"><button className="btn">{t('b_btn')}</button>
          <p role="status" className={`mt-5 ${state === 'err' ? 'text-terracotta' : ''}`}>{state === 'err' ? t('b_err') : state === 'ok' ? t('b_ok') : ''}</p></div>
      </form>
    </div></section>
  )
}
