import { useState, type ChangeEvent, type FormEvent } from 'react'
import { useI18n } from '../i18n'
import { Title } from './ui'
const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const keys = ['name', 'email', 'msg'] as const
export default function Contact() {
  const { t } = useI18n()
  const [v, setV] = useState({ name: '', email: '', msg: '' })
  const [tried, setTried] = useState(false)
  const [done, setDone] = useState(false)
  const bad = { name: !v.name.trim(), email: !re.test(v.email), msg: v.msg.trim().length < 10 }
  const submit = (e: FormEvent) => { e.preventDefault(); setTried(true); setDone(!Object.values(bad).some(Boolean)) }
  const on = (k: keyof typeof v) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setV({ ...v, [k]: e.target.value })
  return (
    <section id="contact" className="mx-auto max-w-7xl px-6 py-24 md:py-36">
      <Title>{t('c_title')}</Title>
      <div className="grid gap-14 md:grid-cols-2">
        <form onSubmit={submit} noValidate className="space-y-6">
          {keys.map(k => {
            const err = tried && bad[k]
            const common = { id: `c-${k}`, value: v[k], onChange: on(k), 'aria-invalid': err, 'aria-describedby': err ? `e-${k}` : undefined, className: 'field' }
            return <div key={k}><label htmlFor={`c-${k}`} className="text-sm">{t(`c_${k}` as const)}</label>
              {k === 'msg' ? <textarea rows={4} {...common} /> : <input type={k === 'email' ? 'email' : 'text'} {...common} />}
              {err && <p id={`e-${k}`} className="mt-1 text-sm text-terracotta">{t(`c_e_${k}` as const)}</p>}</div>
          })}
          <button className="btn">{t('c_send')}</button>
          <p role="status">{done ? t('c_ok') : ''}</p>
        </form>
        <div>
          <iframe title="Map of the Marrakech Medina" loading="lazy" className="h-80 w-full border-0 sepia-[.4]" src="https://www.openstreetmap.org/export/embed.html?bbox=-7.995%2C31.622%2C-7.967%2C31.637&layer=mapnik&marker=31.6295%2C-7.9811" />
          <p className="mt-2 text-sm italic opacity-70">{t('c_pin')}</p>
          <address className="mt-6 space-y-1 font-serif text-xl not-italic"><p>{t('c_addr')}</p><p>{t('c_phone')}</p><p>{t('c_mail')}</p></address>
          <ul className="mt-6 flex gap-6">{['Instagram', 'Facebook', 'WhatsApp'].map(s => <li key={s}><a href="#" rel="noopener" aria-label={`${s} (link to be added)`} className="border-b border-gold hover:text-terracotta">{s}</a></li>)}</ul>
        </div>
      </div>
    </section>
  )
}
