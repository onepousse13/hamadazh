import { useI18n } from '../i18n'
import { rooms, u } from '../data'
import { Img, Title } from './ui'
export default function Rooms({ onBook }: { onBook: (id: string) => void }) {
  const { t, p } = useI18n()
  return (
    <section id="rooms" className="bg-sand/50 px-6 py-24 md:py-36"><div className="mx-auto max-w-7xl">
      <Title note={t('r_note')}>{t('r_title')}</Title>
      <div className="grid gap-14 md:grid-cols-3">
        {rooms.map(r => (
          <article key={r.id} className="group text-center">
            <div className="overflow-hidden rounded-t-[999px]"><Img src={u(r.img)} alt={`${p(r.name)} (placeholder photo)`} className="aspect-[3/4] w-full object-cover transition-transform duration-700 group-hover:scale-105" /></div>
            <h3 className="mt-8 text-4xl">{p(r.name)}</h3>
            <p className="mx-auto mt-3 max-w-xs">{p(r.desc)}</p>
            <ul className="mx-auto mt-5 max-w-xs text-sm">{p(r.am).split('|').map(a => <li key={a} className="border-t border-gold/40 py-1.5">{a}</li>)}</ul>
            <button className="btn mt-7" onClick={() => onBook(r.id)}>{t('r_cta')}</button>
          </article>
        ))}
      </div>
    </div></section>
  )
}
