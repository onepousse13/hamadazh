import { useEffect, useState } from 'react'
import { useI18n } from '../i18n'
const links = ['about', 'rooms', 'experiences', 'gallery', 'booking', 'contact'] as const
export default function Header() {
  const { t, lang, setLang } = useI18n()
  const [solid, setSolid] = useState(false)
  const [open, setOpen] = useState(false)
  useEffect(() => { const f = () => setSolid(scrollY > 60); f(); addEventListener('scroll', f, { passive: true }); return () => removeEventListener('scroll', f) }, [])
  const langs = <div className="flex gap-3 text-sm">{(['en', 'fr'] as const).map(l => <button key={l} onClick={() => setLang(l)} aria-pressed={lang === l} className={lang === l ? 'text-gold' : 'opacity-70 hover:opacity-100'}>{l.toUpperCase()}</button>)}</div>
  return (
    <header className={`fixed inset-x-0 top-0 z-40 transition-colors duration-500 ${solid || open ? 'bg-ivory/95 text-olive backdrop-blur' : 'text-ivory'}`}>
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <a href="#top" className="font-serif text-2xl tracking-[.3em]">HAMADA ZH</a>
        <nav aria-label="Primary" className="hidden items-center gap-8 text-sm tracking-wide lg:flex">
          {links.map(l => <a key={l} href={`#${l}`} className="hover:text-gold">{t(`nav_${l}` as const)}</a>)}
          {langs}<a href="#booking" className="btn !px-6 !py-2.5">{t('book')}</a>
        </nav>
        <button className="px-2 text-2xl lg:hidden" aria-expanded={open} aria-controls="m-nav" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? '×' : '≡'}</button>
      </div>
      {open && <nav id="m-nav" aria-label="Mobile" className="flex flex-col gap-5 px-6 pb-8 text-lg">
        {links.map(l => <a key={l} href={`#${l}`} onClick={() => setOpen(false)}>{t(`nav_${l}` as const)}</a>)}
        {langs}<a href="#booking" onClick={() => setOpen(false)} className="btn text-center">{t('book')}</a>
      </nav>}
    </header>
  )
}
