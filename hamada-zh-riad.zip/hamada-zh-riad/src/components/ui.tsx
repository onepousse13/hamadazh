import { useState, type ReactNode } from 'react'
export function Img({ src, alt, className = '', eager = false }: { src: string; alt: string; className?: string; eager?: boolean }) {
  const [bad, setBad] = useState(false)
  if (bad) return <div role="img" aria-label={alt} className={`bg-gradient-to-br from-terracotta/70 to-olive ${className}`} />
  return <img src={src} alt={alt} loading={eager ? 'eager' : 'lazy'} decoding="async" onError={() => setBad(true)} className={className} />
}
export function Title({ children, note }: { children: ReactNode; note?: string }) {
  return <header className="mb-14 max-w-2xl"><h2 className="text-5xl leading-none md:text-7xl">{children}</h2>{note && <p className="mt-5 font-serif text-xl italic opacity-75">{note}</p>}</header>
}
