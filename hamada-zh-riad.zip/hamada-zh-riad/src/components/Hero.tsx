import { useI18n } from '../i18n'
import { I, u } from '../data'
import { Img } from './ui'
export default function Hero() {
  const { t } = useI18n()
  return (
    <section id="top" className="relative flex h-screen min-h-[620px] items-end overflow-hidden text-ivory">
      <Img eager src={u(I.hero, 1800)} alt="Riad courtyard with swimming pool (placeholder photo)" className="absolute inset-0 h-full w-full animate-zoom object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-olive/90 via-olive/20 to-olive/40" />
      <div className="relative mx-auto w-full max-w-7xl animate-rise px-6 pb-24 md:pb-32">
        <h1 className="max-w-4xl text-5xl leading-[1.05] md:text-8xl">
          <span className="mb-6 block text-2xl tracking-[.4em] text-gold md:text-3xl">HAMADA ZH<span className="sr-only"> — </span></span>{t('h_title')}
        </h1>
        <p className="mt-6 max-w-xl text-lg">{t('h_sub')}</p>
        <a href="#booking" className="btn mt-10">{t('book')}</a>
      </div>
    </section>
  )
}
