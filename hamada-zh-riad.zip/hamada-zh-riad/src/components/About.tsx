import { useI18n } from '../i18n'
import { I, pillars, u } from '../data'
import { Img, Title } from './ui'
export default function About() {
  const { t, p } = useI18n()
  return (
    <section id="about" className="mx-auto grid max-w-7xl gap-16 px-6 py-24 md:grid-cols-2 md:py-36">
      <Img src={u(I.c, 1000)} alt="Moroccan archway (placeholder photo)" className="aspect-[3/4] w-full rounded-t-[999px] object-cover" />
      <div className="self-center">
        <Title>{t('a_title')}</Title>
        <p className="max-w-prose font-serif text-2xl leading-relaxed">{t('a_p1')}</p>
        <p className="mt-4 text-sm italic opacity-60">{t('a_p2')}</p>
        <dl className="mt-12 grid gap-8 sm:grid-cols-2">
          {pillars.map(([h, d]) => <div key={h[0]} className="border-t border-gold pt-4"><dt className="font-serif text-2xl">{p(h)}</dt><dd className="mt-1 text-sm">{p(d)}</dd></div>)}
        </dl>
      </div>
    </section>
  )
}
