import { useEffect, useState } from 'react'
import { useI18n } from '../i18n'
import { cats, gallery, u } from '../data'
import { Img, Title } from './ui'
export default function Gallery() {
  const { t, p } = useI18n()
  const [cat, setCat] = useState('all')
  const [open, setOpen] = useState<number | null>(null)
  const items = gallery.filter(g => cat === 'all' || g.cat === cat)
  const label = (c: string) => p(cats.find(x => x[0] === c)![1])
  const step = (d: number) => setOpen(o => (o === null ? o : (o + d + items.length) % items.length))
  const shut = open === null
  useEffect(() => {
    if (shut) return
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(null); if (e.key === 'ArrowRight') step(1); if (e.key === 'ArrowLeft') step(-1) }
    addEventListener('keydown', k); document.body.style.overflow = 'hidden'
    return () => { removeEventListener('keydown', k); document.body.style.overflow = '' }
  }, [shut, items.length])
  const tab = (k: string, text: string) => <button key={k} onClick={() => setCat(k)} aria-pressed={cat === k} className={`border-b pb-1 text-lg ${cat === k ? 'border-terracotta text-terracotta' : 'border-transparent'}`}>{text}</button>
  const btn = 'absolute text-ivory text-lg px-4 py-3 hover:text-gold'
  return (
    <section id="gallery" className="mx-auto max-w-7xl px-6 py-24 md:py-36">
      <Title note={t('g_note')}>{t('g_title')}</Title>
      <div className="mb-8 flex flex-wrap gap-x-8 gap-y-3">{tab('all', t('g_all'))}{cats.map(([k, l]) => tab(k, p(l)))}</div>
      <div className="grid auto-rows-[200px] grid-cols-2 gap-3 md:auto-rows-[260px] md:grid-cols-3">
        {items.map((g, i) => (
          <button key={g.id + cat} onClick={() => setOpen(i)} aria-label={`${label(g.cat)} ${i + 1}`} className={`group overflow-hidden ${i % 5 === 0 ? 'row-span-2' : ''}`}>
            <Img src={u(g.id, 700)} alt={`${label(g.cat)} (placeholder photo)`} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
          </button>
        ))}
      </div>
      {!shut && items[open] && (
        <div role="dialog" aria-modal="true" aria-label={label(items[open].cat)} className="fixed inset-0 z-50 flex items-center justify-center bg-olive/95 p-4" onClick={() => setOpen(null)}>
          <Img src={u(items[open].id, 1800)} alt={`${label(items[open].cat)} (placeholder photo)`} className="max-h-[85vh] max-w-full object-contain" />
          <button autoFocus className={`${btn} right-2 top-2`} onClick={() => setOpen(null)}>{t('g_close')}</button>
          <button className={`${btn} left-2 top-1/2`} onClick={e => { e.stopPropagation(); step(-1) }} aria-label={t('g_prev')}>‹</button>
          <button className={`${btn} right-2 top-1/2`} onClick={e => { e.stopPropagation(); step(1) }} aria-label={t('g_next')}>›</button>
        </div>
      )}
    </section>
  )
}
