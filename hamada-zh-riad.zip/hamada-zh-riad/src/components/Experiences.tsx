import { useI18n } from '../i18n'
import { experiences } from '../data'
import { Title } from './ui'
export default function Experiences() {
  const { t, p } = useI18n()
  return (
    <section id="experiences" className="bg-olive px-6 py-24 text-ivory md:py-36"><div className="mx-auto max-w-7xl">
      <Title note={t('e_note')}>{t('e_title')}</Title>
      {experiences.map(([h, d]) => (
        <article key={h[0]} className="grid gap-3 border-t border-gold/50 py-8 transition-colors hover:bg-ivory/5 md:grid-cols-[1fr_1.4fr] md:gap-12">
          <h3 className="text-3xl md:text-4xl">{p(h)}</h3><p className="self-center text-lg">{p(d)}</p>
        </article>
      ))}
    </div></section>
  )
}
