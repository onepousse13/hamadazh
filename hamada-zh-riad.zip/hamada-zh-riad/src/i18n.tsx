import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
export type Lang = 'en' | 'fr'
export type Pair = [string, string] // [English, Français]. Swap for i18next later if more languages are needed.
export const T = {
  nav_about: ['The riad', 'Le riad'], nav_rooms: ['Rooms & suites', 'Chambres & suites'], nav_experiences: ['Experiences', 'Expériences'],
  nav_gallery: ['Gallery', 'Galerie'], nav_booking: ['Booking', 'Réservation'], nav_contact: ['Contact', 'Contact'],
  book: ['Book your stay', 'Réserver votre séjour'],
  h_title: ['A Timeless Escape in the Heart of Marrakech', 'Une escapade intemporelle au cœur de Marrakech'],
  h_sub: ['Experience authentic Moroccan elegance in the historic Medina.', 'Vivez l’élégance marocaine authentique au cœur de la Médina historique.'],
  a_title: ['A house built around a courtyard', 'Une maison construite autour d’un patio'],
  a_p1: ['HAMADA ZH is imagined as a traditional riad in the Medina of Marrakech: a sheltered courtyard, the sound of water, and rooms that open inward to light and silence.', 'HAMADA ZH est imaginé comme un riad traditionnel de la Médina de Marrakech : un patio abrité, le bruit de l’eau et des chambres qui s’ouvrent sur la lumière et le silence.'],
  a_p2: ['Placeholder story. Replace with the riad’s true history and the owners’ own words.', 'Texte provisoire. À remplacer par l’histoire réelle du riad et les mots de ses propriétaires.'],
  r_title: ['Rooms & suites', 'Chambres & suites'],
  r_note: ['Sample room types. Details, rates and availability to be confirmed.', 'Types de chambres indicatifs. Détails, tarifs et disponibilités à confirmer.'],
  r_cta: ['Request this room', 'Demander cette chambre'],
  e_title: ['Experiences', 'Expériences'],
  e_note: ['Conceptual offerings, subject to confirmation.', 'Propositions conceptuelles, sous réserve de confirmation.'],
  g_title: ['Gallery', 'Galerie'], g_all: ['All', 'Tout'], g_close: ['Close', 'Fermer'], g_prev: ['Previous', 'Précédent'], g_next: ['Next', 'Suivant'],
  g_note: ['Placeholder photography.', 'Photographies provisoires.'],
  b_title: ['Plan your stay', 'Planifiez votre séjour'],
  b_demo: ['Demonstration only: no booking is made and no payment is taken.', 'Démonstration uniquement : aucune réservation n’est effectuée et aucun paiement n’est prélevé.'],
  b_in: ['Check-in', 'Arrivée'], b_out: ['Check-out', 'Départ'], b_guests: ['Guests', 'Voyageurs'], b_room: ['Room', 'Chambre'],
  b_pick: ['Select a room', 'Choisir une chambre'], b_btn: ['Check availability', 'Vérifier la disponibilité'],
  b_err: ['Complete every field. Check-out must be after check-in.', 'Complétez tous les champs. Le départ doit suivre l’arrivée.'],
  b_ok: ['Demo only: nothing was sent. Connect a booking engine to go live.', 'Démo uniquement : rien n’a été envoyé. Connectez un moteur de réservation pour la mise en ligne.'],
  c_title: ['Find us in the Medina', 'Retrouvez-nous dans la Médina'],
  c_name: ['Name', 'Nom'], c_email: ['Email', 'E-mail'], c_msg: ['Message', 'Message'], c_send: ['Send message', 'Envoyer le message'],
  c_e_name: ['Enter your name.', 'Saisissez votre nom.'], c_e_email: ['Enter a valid email address.', 'Saisissez une adresse e-mail valide.'],
  c_e_msg: ['Write at least 10 characters.', 'Écrivez au moins 10 caractères.'],
  c_ok: ['Demo form: nothing was sent.', 'Formulaire de démonstration : rien n’a été envoyé.'],
  c_addr: ['[Street address to be confirmed]', '[Adresse à confirmer]'], c_phone: ['[Phone number]', '[Numéro de téléphone]'], c_mail: ['[Email address]', '[Adresse e-mail]'],
  c_pin: ['The map shows the Medina area. The pin is a placeholder.', 'La carte montre la Médina. Le repère est provisoire.'],
  f_tag: ['Boutique riad, Medina of Marrakech', 'Riad de charme, Médina de Marrakech'],
} satisfies Record<string, Pair>
type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (k: keyof typeof T) => string; p: (v: Pair) => string }
const C = createContext<Ctx>(null!)
export const useI18n = () => useContext(C)
export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>(() => (navigator.language.startsWith('fr') ? 'fr' : 'en'))
  useEffect(() => { document.documentElement.lang = lang }, [lang])
  const i = lang === 'en' ? 0 : 1
  return <C.Provider value={{ lang, setLang, t: k => T[k][i], p: v => v[i] }}>{children}</C.Provider>
}
